// pages/index.js

const Microfrontend1 = () => {
  return (
    <div>
      <h2>Microfrontend 1</h2>
      <p>This is Microfrontend FIRST content.</p>
    </div>
  );
};

export default Microfrontend1;
